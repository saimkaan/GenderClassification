/**
 * 
 */
package de.uni_koeln.ai.student.mazey.imdi.crawler.java;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileCrawler {

	private List<File> files = new ArrayList<File>();

	/**
	 * Constructor takes a folder as input and creates a list of files.</br>
	 * </br>
	 * The parameter is turned into a file object. Then it checks whether</br> 
	 * the file exists and turns it into an array. Finally, each file that is </br>
	 * not a directory is stored in a list.</br>
	 * @param folder String representing path to a folder.
	 */
	
	public FileCrawler(String folder) {
		System.out.println("Feteching images from folder ...\n");
		files = crawlFiles(folder);
		System.out.println("Folder contains " + files.size() + " images.\n");
	}

	private List<File> crawlFiles(String folder) {
		List<File> result = new ArrayList<File>();
		File files = new File(folder);
		if (files.exists()) {
			File[] fileArray = files.listFiles();
			for (File file : fileArray) {
				if (!file.isHidden()) {
					if (file.isDirectory()) {
						result.addAll(crawlFiles(file.getPath()));
					} else {
						result.add(file);
					}
				}
			}
		} else {
			System.err.println("File does not exist.");
		}
		return result;
	}

	/**
	 * Returns list of files.</br>
	 * </br>
	 * @return	List of files.
	 */
	
	public List<File> getList() {
		return files;
	}

}
