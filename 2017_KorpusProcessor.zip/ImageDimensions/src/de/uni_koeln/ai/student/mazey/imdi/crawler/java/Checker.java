/**
 * 
 */
package de.uni_koeln.ai.student.mazey.imdi.crawler.java;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

public class Checker {

	private List<File> bigImages = new ArrayList<File>();
	private final int sideA = 500;
	private final int sideB = 333;
	private boolean bigger;

	/**
	 * Constructor is used to iterate trough a List of images and checks whether its dimensions </br>
	 * are bigger than 500 x 333;
	 * </br>
	 * To do so, it iterates through the list and returns the corresponding boolean. 
	 * 
	 * @param files	List containing images
	 * @throws IndexOutOfBoundsException
	 */
	
	public Checker(List<File> files) throws IndexOutOfBoundsException {
		System.out.println("Fetching relevant images for resizing ... \n");
		for (File currentFile : files) {
			try {
				boolean bigger = checkSize(currentFile);
				if (bigger) {
					bigImages.add(currentFile);
				}
			} catch (IOException e) {
				System.out.println(e);
			}
		}
		System.out.println("Number of images to resize:\t" + bigImages.size() + "\n");
	}

	private boolean checkSize(File currentFile) throws IOException {
		BufferedImage bimg = ImageIO.read(currentFile);
		if (bimg != null) {
			int x = bimg.getWidth();
			int y = bimg.getHeight();
			if (x > sideA & y > sideB) {
				bigger = true;
			} else if (x > sideB & y > sideA) {
				bigger = true;
			} else {
				bigger = false;
			}
		} else {
			System.err.println("*** BufferedImage is null ***");
		}
		return bigger;
	}

	public List<File> getList() {
		return bigImages;
	}

}
