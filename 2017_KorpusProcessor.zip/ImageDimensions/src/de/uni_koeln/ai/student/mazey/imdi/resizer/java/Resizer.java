/**
 * 
 */
package de.uni_koeln.ai.student.mazey.imdi.resizer.java;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class Resizer {

	private List<File> resizedImages = new ArrayList<File>();

	/**
	 * Constructor is used to resize an image according to user's preference.</br>
	 * </br>
	 * To do so, it iterates through a list of files. Then a method is evoked</br>
	 * that uses the current file, the preferred image dimensions and a</br>
	 * path to a directory in which the resized image is to be stored.</br>
	 * 
	 * @param file	List containing files.
	 * @param sideA	Integer that represents the length of one side.
	 * @param sideB	Integer that represents the length of one side.
	 * @param directory	String the defines the path in which the new image is to be stored.
	 */
	
	public Resizer(List<File> file, int sideA, int sideB, String directory) {
		System.out.println("Resizing images ... \n");
		for (File currentFile : file) {
			File resizedImage = resize(currentFile, sideA, sideB, directory);
			resizedImages.add(resizedImage);
		}
		System.out.println("Number of images that have just been resized:\t" + resizedImages.size());
		for (File currentResizedFile : resizedImages) {
			System.out.println("Recently resized image:\t" + currentResizedFile.getAbsolutePath());
		}
	}

	private File resize(File currentFile, int sideA, int sideB, String directory) {
		File resized = null;
		Random rn = new Random();
		int randomInt = rn.nextInt(5000);
		String resizedImage = directory + "/" + randomInt + ".jpg";
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		Mat sourceI = Imgcodecs.imread(currentFile.getAbsolutePath());
		Mat destI = new Mat();

		if (sourceI.height() > sideB & sourceI.width() > sideA) {
			Size size = new Size(sideA, sideB);
			Imgproc.resize(sourceI, destI, size);
		} else if (sourceI.height() > sideA & sourceI.width() > sideB) {
			Size size = new Size(sideB, sideA);
			Imgproc.resize(sourceI, destI, size);
		}

		Imgcodecs.imwrite(resizedImage, destI);
		resized = new File(resizedImage);
		return resized;
	}

	public List<File> getList() {
		return resizedImages;
	}

}
