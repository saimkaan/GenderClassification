package de.uni_koeln.ai.student.mazey.imdi.test.java;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import de.uni_koeln.ai.student.mazey.imdi.crawler.java.Checker;
import de.uni_koeln.ai.student.mazey.imdi.crawler.java.FileCrawler;
import de.uni_koeln.ai.student.mazey.imdi.resizer.java.Flipper;
import de.uni_koeln.ai.student.mazey.imdi.resizer.java.Resizer;

public class Tests {
	
	private final String testFolder = "TestFiles";
	private final String testResizedFolder = "ResizedImages";
	private final String testFlippedFolder = "FlippedFiles";
	private final String resizedFolder = "/Users/marcozeyen/Google Drive/Artificial Intelligence/Marco/images/images_c/male_statue_resized/";
	private final String mirrorFolder = "/Users/marcozeyen/Google Drive/Artificial Intelligence/Marco/images/images_c/male_statue_resized_mirror/";
	private String aiFolder = "/Users/marcozeyen/Google Drive/Artificial Intelligence/Marco/images/images_c/female_bust/";
	private FileCrawler crawler = new FileCrawler(testFolder);

	@Test
	public void testCrawler() {
		List<File> files = crawler.getList();
		Assert.assertTrue("List contains " + files.size() + " files.", files.size() == 6);
	}

	@Test
	public void testSize() {
		List<File> files = crawler.getList();
		Checker checker = new Checker(files);
		List<File> relevantFiles = checker.getList();
		Assert.assertTrue("List contains " + relevantFiles.size() + " files.", relevantFiles.size() == 5);
	}
	
	@Test
	public void testResize() {
		List<File> files = crawler.getList();
		Checker checker = new Checker(files);
		List<File> relevantFiles = checker.getList();
		Resizer resizer = new Resizer(relevantFiles, 500, 333, resizedFolder);
		List<File> resizedFiles = resizer.getList();
		Assert.assertTrue("List contains " + resizedFiles.size() + " files.", resizedFiles.size() == 5);
	}
	
	@Test
	public void testFlipper() throws IOException {
		List<File> files = crawler.getList();
//		Checker checker = new Checker(files);
//		List<File> relevantFiles = checker.getList();
		Flipper flipper = new Flipper(files, testFlippedFolder);
		Assert.assertTrue(flipper.getList().size() == 6);
	}

}