/**
 * 
 */
package de.uni_koeln.ai.student.mazey.imdi.resizer.java;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;

public class Flipper {

	private List<File> flippedImages = new ArrayList<File>();

	/**
	 * Constructor is used to mirror an image.</br>
	 * </br>
	 * To do so, the constructor evokes method that uses as input an file</br>
	 * and a path that represents the destination folder in which the</br>
	 * resized image is to be stored.</br>
	 * @param relevantFiles	List of files that are relevant for mirroring.
	 * @param destinationDir String that defines the destination folder.
	 * @throws IOException
	 */
	
	public Flipper(List<File> relevantFiles, String destinationDir) throws IOException {
		System.out.println("Flipping images ...\n");
		for (File currentFile : relevantFiles) {
			System.out.println(currentFile.getAbsolutePath());
			File flippedImage = flip(currentFile, destinationDir);
			flippedImages.add(flippedImage);
		}
		System.out.println("Number of images that have just been resized:\t" + flippedImages.size());
	}

	private File flip(File currentFile, String destinationDir) throws IOException {
		File flipped = null;

		BufferedImage simg = ImageIO.read(currentFile);
		int height = simg.getHeight();
		int width = simg.getWidth();

		BufferedImage mimg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

		for (int y = 0; y < height; y++) {
			for (int lx = 0, rx = width - 1; lx < width; lx++, rx--) {
				int p = simg.getRGB(lx, y);
				mimg.setRGB(rx, y, p);
			}
		}

		Random random = new Random();
		int randomInt = random.nextInt(5000);
		flipped = new File(destinationDir + "/" + randomInt + ".png");
		ImageIO.write(mimg, "png", flipped);
		return flipped;
	}

	public List<File> getList() {
		return flippedImages;
	}

}
